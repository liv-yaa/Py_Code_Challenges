staging
============

This folder contains challenges that are still under development.  These challenges might need some minor tweaks or polishing before being placed in the general repository.